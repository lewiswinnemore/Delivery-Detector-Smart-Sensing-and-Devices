package edu.temple.deliverylightsense;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.ProgressDialog;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import EmailSender.GmailSender;

public class MainActivity extends AppCompatActivity {

    private TextView txtErrorMessage;
    private EditText editTextThreshold;
    private EditText editTextEmail;
    private ConstraintLayout constraintLayoutMain;
    private String Recipient = "";

    private float floatThreshold = 320;

    private SensorManager sensorManager;
    private Sensor sensorLight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextThreshold = findViewById(R.id.editTextThreshold);
        constraintLayoutMain = findViewById(R.id.phoneLayout);
        txtErrorMessage = findViewById(R.id.txtErrorMessage);
        editTextEmail = findViewById(R.id.editTextEmail);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensorLight = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        SensorEventListener sensorEventListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                float floatSensorValue = event.values[0];

                if(floatSensorValue < floatThreshold)
                {
                    txtErrorMessage.setText("No packages yet.");
                }
                else
                {
                    sendMessage();
                }

            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };

        sensorManager.registerListener(sensorEventListener, sensorLight,SensorManager.SENSOR_DELAY_UI);


    }

    public void buttonSetThreshold(View view)
    {
        if (editTextThreshold.getText().toString().isEmpty()) {
            return;
        }
        floatThreshold = Float.valueOf(editTextThreshold.getText().toString());

    }

    public void buttonSetEmail(View view)
    {
        if (editTextEmail.getText().toString().isEmpty())
        {
            txtErrorMessage.setText("Please Enter a Valid Email!");
        }
        else
        {
            Recipient = editTextEmail.getText().toString();
        }

    }

    private void sendMessage(){
        final ProgressDialog dialog = new ProgressDialog(MainActivity.this);
        dialog.setTitle("Sending Email");
        dialog.setMessage("Please wait");
        dialog.show();
        Thread sender = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    GmailSender sender = new GmailSender("joviebandoy@gmail.com", "Magi#5427");
                    sender.sendMail("DeliveryLightSense",
                            "Your package was delivered",
                            "joviebandoy@gmail.com",
                            Recipient);
                    dialog.dismiss();
                } catch (Exception e) {
                    Log.e("mylog", "Error: " + e.getMessage());
                }
            }
        });
        sender.start();
    }
}